readme

html을 크롬에 띄워서 작동시키면 되겠습니다.
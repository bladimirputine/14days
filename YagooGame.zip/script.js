document.addEventListener('DOMContentLoaded', function () {
    const answer = generateRandomNumber();
    console.log(`컴퓨터가 생성한 정답 숫자: ${answer}`); // 컴퓨터가 생성한 숫자를 콘솔에 표시

    let attempts = 0;
    const history = [];
  
    const guessInput = document.getElementById('guessInput');
    const guessButton = document.getElementById('guessButton');
    const resultDiv = document.getElementById('result');
    const attemptsDiv = document.getElementById('attempts');
    const historyDiv = document.getElementById('history'); // 수정된 부분
  
    guessButton.addEventListener('click', function () {
      const guess = guessInput.value;
  
      if (!isValidGuess(guess)) {
        resultDiv.textContent = '유효한 세 자리 숫자를 입력하세요.';
        return;
      }
  
      attempts++;
      const { s, b } = checkGuess(answer, guess);
      const resultText = `${s}S ${b}B`;
      const historyText = `${attempts}. 번째 시도: ${guess} - ${resultText}`;
  
      if (s === 3) {
        resultDiv.textContent = `★맞췄습니다!! 게임을 종료합니다!!★`;
        attemptsDiv.textContent = `시도 횟수: ${attempts}회`;
        guessButton.disabled = true;
      } else {
        resultDiv.textContent = resultText;
        history.push(historyText); // 수정된 부분
        updateHistory(); // 수정된 부분
      }
    });
  
    function updateHistory() { // 수정된 부분
      historyDiv.innerHTML = history.join('<br>');
    }
  });
  
  // 나머지 함수들은 그대로 유지됩니다.
  
  
  function generateRandomNumber() {
    const digits = [];
    while (digits.length < 3) {
      const digit = Math.floor(Math.random() * 10);
      if (!digits.includes(digit)) {
        digits.push(digit);
      }
    }
    return digits.join('');
  }

  function isValidGuess(guess) {
    if (!/^\d{3}$/.test(guess)) {
      return false;
    }
    
    // 중복된 숫자 체크
    const digits = new Set(guess);
    return digits.size === 3;
  }
  
  
  function checkGuess(answer, guess) {
    let s = 0;
    let b = 0;
  
    for (let i = 0; i < 3; i++) {
      if (guess[i] === answer[i]) {
        s++;
      } else if (answer.includes(guess[i])) {
        b++;
      }
    }
  
    return { s, b };
  }
  